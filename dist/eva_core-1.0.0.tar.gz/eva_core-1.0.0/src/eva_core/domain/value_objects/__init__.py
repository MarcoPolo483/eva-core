"""Value objects - immutable objects without identity."""
