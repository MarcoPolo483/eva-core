"""Domain entities - core business objects with identity."""
