"""Domain layer - entities, value objects, and business logic."""
